"use client";

import { motion } from "framer-motion";
import { ArrowLeft, BookOpen, Target, Users, Rocket, Brain, Eye, Lightbulb } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function LearnMore() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Navigation */}
      <nav className="p-4 bg-white shadow-sm">
        <Link href="/">
          <Button variant="ghost" className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </Link>
      </nav>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Introduction */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <BookOpen className="w-12 h-12 text-blue-600 mb-4" />
          <h1 className="text-4xl font-bold mb-6">Beyond Knowledge Transfer - Edu Game Master</h1>
          <div className="prose prose-lg">
            <p className="text-gray-700 leading-relaxed">
              In a time when information is available to everyone in just two clicks, true innovation lies beyond knowledge transfer—it comes from wisdom. As we transition into the wisdom economy, we prioritize not only what we know but how we apply it to create meaningful impact. In this new era, asking the right questions becomes just as important as finding the answers. Through a human-centered approach that values empathy, collaboration, and ethical growth, we aim to shape technology according to human values, creating a future where wisdom leads progress.
            </p>
          </div>
        </motion.section>

        {/* Challenges */}
        <motion.section
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="mb-16"
        >
          <Target className="w-12 h-12 text-red-600 mb-4" />
          <h2 className="text-3xl font-bold mb-6">Challenge and Consequences</h2>
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Lack of Modern Educational Opportunities in Bijeljina</h3>
              <p className="text-gray-700">
                Bijeljina faces a severe lack of modern educational opportunities that keep up with rapid technological advancements. Young people and women do not have access to resources that would enable them to develop key skills for the future.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Skills Needed for the Modern Job Market</h3>
              <p className="text-gray-700">
                Without adequate skills, citizens face limited opportunities in the modern job market. This reduces their competitiveness and makes it difficult for them to contribute to local and broader societal development.
              </p>
            </div>
          </div>
        </motion.section>

        {/* Solution */}
        <motion.section
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="mb-16"
        >
          <Rocket className="w-12 h-12 text-green-600 mb-4" />
          <h2 className="text-3xl font-bold mb-6">Solution</h2>
          <div className="space-y-8">
            {solutions.map((solution, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-3">{solution.title}</h3>
                <div className="prose prose-lg">
                  <p className="text-gray-700">{solution.content}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        {/* Methodology */}
        <motion.section
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="mb-16"
        >
          <Brain className="w-12 h-12 text-purple-600 mb-4" />
          <h2 className="text-3xl font-bold mb-6">Our Approach - Wisdom Economy</h2>
          <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
            <p className="text-gray-700 mb-6">
              The academy uses a live education method through interactive workshops, which are based on real-life situations and practical examples. Each workshop is designed to enable participants to apply the acquired knowledge immediately in practice, helping them develop confidence and a better understanding of complex topics.
            </p>
          </div>
          <h3 className="text-2xl font-bold mb-4">Methodology</h3>
          <div className="grid gap-6">
            {methodologies.map((method, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
                <h4 className="text-lg font-semibold mb-2">{method.title}</h4>
                <p className="text-gray-700">{method.description}</p>
              </div>
            ))}
          </div>
        </motion.section>

        {/* Vision */}
        <motion.section
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="mb-16"
        >
          <Eye className="w-12 h-12 text-blue-600 mb-4" />
          <h2 className="text-3xl font-bold mb-6">Our Vision</h2>
          <div className="bg-white p-6 rounded-lg shadow-sm prose prose-lg">
            <p className="text-gray-700">
              In the long term, Bijeljina as a digital center for lifelong learning, empowering learners and encouraging local development. Simultaneously building an Innovative - Creative hub.
            </p>
            <p className="text-gray-700">
              Our vision is for Bijeljina to become a recognizable digital center for lifelong learning, where modern educational methods tailored to the needs of the local community will be developed. Through continuous support in learning and the development of key skills, we want to empower everyone willing to learn, providing them with opportunities for professional and personal growth.
            </p>
          </div>
        </motion.section>
      </div>
    </main>
  );
}

const solutions = [
  {
    title: "Establishment of an Academy for Critical, Creative, and Innovative Thinking",
    content: "The first phase of our project involves establishing an academy in Bijeljina focused on the development of critical thinking and research, with certifications from global platforms such as Amazon, Meta, LinkedIn, Google, and IBM."
  },
  {
    title: "Collaboration with Creative Mornings and EdHeroes Hub for Support",
    content: "EdHeroes is a global network dedicated to improving access to quality education, aligned with the UN's Sustainable Development Goal 4 (SDG 4). It connects individuals and organizations worldwide to develop customized educational solutions that respect local needs and specificities."
  },
  {
    title: "Building a Gamified Educational Platform",
    content: "The project will focus on building an innovative, gamified educational platform that will enable personalized learning."
  },
  {
    title: "Stakeholders and Partners",
    content: "Collaboration with organizations such as the Swiss Entrepreneurship Program (Swiss EP), Foundation 787, DiaLab diaspora program, embassies, and GIZ can significantly contribute to the development of our innovative creative hub."
  }
];

const methodologies = [
  {
    title: "Problem-Based Learning (PBL)",
    description: "In each workshop, participants face a specific problem or challenge relevant to local conditions or their community. This methodology encourages critical thinking, as participants analyze the situation, ask questions, and develop solutions through teamwork."
  },
  {
    title: "Experiential Learning",
    description: "The workshops are structured so that participants learn through experience, meaning they go through a series of activities that simulate real-life situations. This encourages greater understanding and better application of acquired skills because they learn through practical examples rather than just theory."
  },
  {
    title: "Reflective Practice",
    description: "Each session includes time for reflection, where participants analyze what they have learned to better understand their experience and adjust their approach to future situations. Reflection helps participants become aware of their beliefs and recognize ways to improve their approaches."
  }
];