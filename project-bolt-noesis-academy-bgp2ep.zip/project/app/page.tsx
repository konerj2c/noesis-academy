"use client";

import { motion } from "framer-motion";
import { 
  Brain, 
  Target, 
  Puzzle, 
  Users, 
  Rocket,
  GraduationCap,
  Eye,
  Heart
} from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center text-center px-4">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 z-0" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto z-10"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            Noesis Academy
          </h1>
          <p className="text-2xl md:text-3xl text-gray-700 mb-8">
            Smartex Innovative Creative Hub
          </p>
          <Link href="/learn-more">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
            >
              Learn More
            </Button>
          </Link>
        </motion.div>
      </section>

      {/* Beyond Knowledge Transfer Section */}
      <section className="py-20 px-4 bg-white">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <Brain className="w-16 h-16 mx-auto mb-6 text-blue-600" />
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Beyond Knowledge Transfer - Edu Game Master
          </h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            In a time when information is available to everyone in just two clicks, true innovation lies beyond knowledge transfer—it comes from wisdom. As we transition into the wisdom economy, we prioritize not only what we know but how we apply it to create meaningful impact.
          </p>
        </motion.div>
      </section>

      {/* Challenges Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Challenges and Consequences
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-white p-8 rounded-xl shadow-lg"
            >
              <Target className="w-12 h-12 text-red-500 mb-4" />
              <h3 className="text-xl font-bold mb-4">
                Lack of Modern Educational Opportunities
              </h3>
              <p className="text-gray-700">
                Bijeljina faces a severe lack of modern educational opportunities that keep up with rapid technological advancements.
              </p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-white p-8 rounded-xl shadow-lg"
            >
              <Puzzle className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-bold mb-4">
                Skills for the Modern Job Market
              </h3>
              <p className="text-gray-700">
                Without adequate skills, citizens face limited opportunities in the modern job market.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Our Solution
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {solutions.map((solution, index) => (
              <motion.div
                key={index}
                whileHover={{ scale: 1.05 }}
                className="bg-gray-50 p-8 rounded-xl shadow-lg"
              >
                {solution.icon}
                <h3 className="text-xl font-bold mb-4">{solution.title}</h3>
                <p className="text-gray-700">{solution.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <Eye className="w-16 h-16 mx-auto mb-6 text-white" />
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Vision</h2>
          <p className="text-lg leading-relaxed">
            In the long term, we envision Bijeljina as a digital center for lifelong learning, empowering learners and encouraging local development while building an Innovative - Creative hub.
          </p>
        </motion.div>
      </section>

      {/* Support Us Section */}
      <section className="py-20 px-4 bg-white">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <Heart className="w-16 h-16 mx-auto mb-6 text-red-500 animate-pulse" />
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Support Us</h2>
          <p className="text-xl text-gray-700 mb-8 italic">
            "With intelligence and your expertise"
          </p>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Join us in shaping the future of education where wisdom meets innovation. Your expertise can help bridge the gap between knowledge and practical application, creating meaningful impact in our community.
          </p>
          <motion.div
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            <Button
              size="lg"
              className="bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white px-8 py-6 text-lg"
            >
              Support Our Vision
            </Button>
          </motion.div>
        </motion.div>
      </section>
    </main>
  );
}

const solutions = [
  {
    icon: <GraduationCap className="w-12 h-12 text-purple-500 mb-4" />,
    title: "Academy Establishment",
    description: "Creating an academy focused on critical thinking and research, with global certifications."
  },
  {
    icon: <Users className="w-12 h-12 text-blue-500 mb-4" />,
    title: "Global Collaboration",
    description: "Partnering with Creative Mornings and EdHeroes Hub for worldwide support and opportunities."
  },
  {
    icon: <Rocket className="w-12 h-12 text-green-500 mb-4" />,
    title: "Gamified Learning",
    description: "Building an innovative, gamified educational platform for personalized learning experiences."
  }
];